package loadbalancedemo;

import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.netflix.ribbon.RibbonAutoConfiguration;
import org.springframework.cloud.netflix.ribbon.RibbonClients;
import org.springframework.context.annotation.Configuration;

/**
 * Created by Administrator on 2017/6/22/022.
 */
@Configuration
@AutoConfigureAfter(RibbonAutoConfiguration.class)
@RibbonClients(defaultConfiguration = LoadbalanceStrategyConfiguration.class)
@EnableConfigurationProperties
public class LoadbalanceAutoConfiguration {


}
