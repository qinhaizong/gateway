package loadbalancedemo;

import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableMap;
import com.netflix.client.config.CommonClientConfigKey;
import com.netflix.client.config.DefaultClientConfigImpl;
import com.netflix.client.config.IClientConfig;
import com.netflix.client.config.IClientConfigKey;
import com.netflix.config.ConfigurationManager;
import com.netflix.loadbalancer.ConfigurationBasedServerList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.util.StringUtils;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by Administrator on 2017/6/22/022.
 */
@Configuration
public class LoadbalanceStrategyConfiguration {

    @Value("${ribbon.client.name:default}")
    private String clientName = "client";

    private String strategyKey = "loadbalance.strategy";

    //private String defaultStrategy = "ribbon-eureka";

    private Map<String, Map<IClientConfigKey, String>> strategyMap = ImmutableBiMap.of("ribbon-config", ImmutableMap.of(CommonClientConfigKey.NIWSServerListClassName, ConfigurationBasedServerList.class.getName()));

    @Autowired
    private Environment env;

    @Bean
    public IClientConfig ribbonClientConfig() {
        Map<String, Object> pros = new LinkedHashMap<>();

        if (env instanceof ConfigurableEnvironment) {
            ConfigurableEnvironment environment = (ConfigurableEnvironment) env;
            environment.getPropertySources().forEach(propertySource -> {
                if (propertySource.getSource() instanceof LinkedHashMap) {
                    LinkedHashMap map = (LinkedHashMap) propertySource.getSource();
                    String pro = clientName + "." + strategyKey;
                    if (map.containsKey(pro)) {
                        String val = environment.getProperty(pro);
                        if (StringUtils.hasText(val) && strategyMap.containsKey(val)) {
                            Map<IClientConfigKey, String> configKeyStringMap = strategyMap.get(val);
                            configKeyStringMap.forEach((iClientConfigKey, s) -> {
                                pros.put(clientName + ".ribbon." + iClientConfigKey.key().toString(), s);
                                ConfigurationManager.getConfigInstance().addProperty(clientName + "." + iClientConfigKey.key().toString(), s);
                            });
                        }
                    }
                }
            });
            environment.getPropertySources().addFirst(new MapPropertySource("msa", pros));
        }
        DefaultClientConfigImpl config = new DefaultClientConfigImpl();
        config.loadProperties(this.clientName);
        return config;
    }
}
