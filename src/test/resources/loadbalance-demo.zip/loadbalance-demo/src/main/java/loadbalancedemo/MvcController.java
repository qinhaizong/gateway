package loadbalancedemo;

import com.netflix.loadbalancer.Server;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.cloud.netflix.ribbon.SpringClientFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

/**
 * Created by Administrator on 2017/6/23/023.
 */
@RestController
public class MvcController {

    @Autowired
    LoadBalancerClient balancerClient;

    @GetMapping("go/{serviceName}")
    public String go(@PathVariable String serviceName) {
        ServiceInstance server = balancerClient.choose(serviceName);
        return UriComponentsBuilder.newInstance().host(server.getHost()).port(server.getPort()).build().toString();
    }


    @Autowired
    SpringClientFactory clientFactory;

    @GetMapping("get/{serviceName}")
    public String get(@PathVariable String serviceName) {
        Server server = clientFactory.getLoadBalancer(serviceName).chooseServer(serviceName);
        return UriComponentsBuilder.newInstance().host(server.getHost()).port(server.getPort()).build().toString();
    }
}
