package loadbalancedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

/**
 * Created by Administrator on 2017/6/23/023.
 */
@SpringBootApplication
@EnableEurekaClient
public class LoadbalanceApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoadbalanceApplication.class, args);
    }
}
